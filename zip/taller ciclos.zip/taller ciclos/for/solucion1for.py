#Crea un bucle for que cuente de 0 a 10, e imprima números impares en la pantalla. Usa el
#esqueleto de abajo: 


for i in range (1,11):
    if i % 2:
         print(i)