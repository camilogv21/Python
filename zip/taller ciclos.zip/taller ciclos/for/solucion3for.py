#Crea un programa con un bucle for. El programa debe iterar sobre una cadena de dígitos,
#reemplazar cada 0 con x, e imprimir la cadena modificada en la pantalla. Usa el esqueleto de abajo:


for digit in "0165031806510":
    rem=digit.replace("0","X")
    print(rem)