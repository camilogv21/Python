#Escribir todos los números del 100 al 0 de 7 en 7.

for num in range (100,0,-7):
    print(num)
