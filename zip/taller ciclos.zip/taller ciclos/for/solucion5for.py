#Pedir 15 números y escribir la suma total.

suma = 0
for num in range(0,15):

   num= int(input("digite 15 numeros: "))
   suma = suma + num
print(suma)