#Crea un bucle while que cuente de 0 a 10, e imprima números impares en la pantalla.

x = 0 

while x < 11:
    x += 1
    if x % 2:
         print(x)

